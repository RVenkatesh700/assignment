import React,{useState} from 'react'
import "./styles.css";

export default function App() {
   const[change,setChange]= useState("i changed");
    const text=()=>{
      setChange("");
    }
  return (
    <div className="App" >
     <form>
       
         <label>Char length</label>
         <input type="number" /> 
          <input type="color"/>  
          <input  type="text" value="i changed" onChanged="text" />
          <input type="range"  />    
     
     </form>
    </div>
  );
}
